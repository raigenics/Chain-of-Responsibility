﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ChainOfResponsibility.Models;

namespace ChainOfResponsibility.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ProcessPayment()
        {
            var product = GetSelectedProductDetail();

            var handler = new VoucherPaymentHandler();

            handler.SetNext(new WalletPaymentHandler())
                .SetNext(new DebitCardPaymentHandler())
                .SetNext(new CreditCardPaymentHandler());

            handler.Handle(product);

            ViewBag.HandledBy = product.HandledBy;

            //VoucherPaymentSystem voucherPayment = new VoucherPaymentSystem();
            //var voucherValue = voucherPayment.VoucherValue;

            //var remainingAmount = voucherPayment.PayFromVoucher(product.Cost);
            //if (remainingAmount <= 0)
            //{
            //    ViewBag.HandledBy = "Payment done from shopping voucher !";
            //}
            //else
            //{
            //    WalletPaymentSystem walletPayment = new WalletPaymentSystem();
            //    var walletValue = walletPayment.WalletValue;

            //    var _remainingAmount = walletPayment.PayFromWallet(remainingAmount);
            //    if (_remainingAmount <= 0)
            //    {
            //        ViewBag.HandledBy = "Payment done from shopping wallet !";
            //    }
            //    else
            //    {
            //        CreditCardPaymentSystem creditCard = new CreditCardPaymentSystem();
            //        DebitCardPaymentSystem debitCard = new DebitCardPaymentSystem();

            //        if (debitCard.CanPayDebitCard(_remainingAmount))
            //        {
            //            debitCard.PayFromDebitCard(_remainingAmount);
            //            ViewBag.HandledBy = "Payment done from debit card !";
            //        }
            //        else if (creditCard.CanPayCreditCard(_remainingAmount))
            //        {
            //            creditCard.PayFromCreditCard(_remainingAmount);
            //            ViewBag.HandledBy = "Payment done from credit card !";
            //        }
            //        else
            //        {
            //            ViewBag.HandledBy = "Cannot handle request. No sufficient balance.";
            //        }
            //    }
            //}

            return View("Index");
        }

        private Product GetSelectedProductDetail()
        {
            Product product = new Product();
            if (!string.IsNullOrEmpty(Request.Form["Camera"]))
            {
                product.Name = "SLR Camera";
                product.Cost = int.Parse(Request.Form["CameraPrice"]);
            }
            if (!string.IsNullOrEmpty(Request.Form["IPhone"]))
            {
                product.Name = "IPhone";
                product.Cost = int.Parse(Request.Form["IPhonePrice"]);
            }
            if (!string.IsNullOrEmpty(Request.Form["Watch"]))
            {
                product.Name = "Watch";
                product.Cost = int.Parse(Request.Form["WatchPrice"]);
            }

            return product;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
